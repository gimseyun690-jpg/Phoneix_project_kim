import 'package:flutter/material.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:mapbox_maps_example/utils.dart';

import 'example.dart';

class PolylineAnnotationExample extends StatefulWidget implements Example {
  @override
  final Widget leading = const Icon(Icons.map);
  @override
  final String title = 'Polyline Annotations';
  @override
  final String? subtitle = null;

  @override
  State<StatefulWidget> createState() => PolylineAnnotationExampleState();
}

class PolylineAnnotationExampleState extends State<PolylineAnnotationExample> {
  MapboxMap? mapboxMap;
  PolylineAnnotation? polylineAnnotation;
  PolylineAnnotationManager? polylineAnnotationManager;
  List<PolylineAnnotation> annotations = [];
  int styleIndex = 1;

  _onMapCreated(MapboxMap mapboxMap) {
    this.mapboxMap = mapboxMap;
    mapboxMap.setCamera(CameraOptions(
        center: Point(coordinates: Position(0, 0)), zoom: 1, pitch: 0));
    mapboxMap.annotations.createPolylineAnnotationManager().then((value) {
      polylineAnnotationManager = value;
      createOneAnnotation();
      final positions = <List<Position>>[];
      for (int i = 0; i < 99; i++) {
        positions.add(createRandomPositionList());
      }

      polylineAnnotationManager
          ?.createMulti(positions
              .map((e) => PolylineAnnotationOptions(
                  geometry: LineString(coordinates: e),
                  lineColor: createRandomColor()))
              .toList())
          .then((createdAnnotations) {
        annotations =
            createdAnnotations.whereType<PolylineAnnotation>().toList();
      });
      polylineAnnotationManager?.tapEvents(onTap: (annotation) {
        // ignore: avoid_print
        print("onAnnotationClick, id: ${annotation.id}");
      });
      polylineAnnotationManager?.longPressEvents(onLongPress: (annotation) {
        // ignore: avoid_print
        print("onAnnotationLongPress, id: ${annotation.id}");
      });
    });
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget _update() {
    return TextButton(
      child: Text('update a polyline annotation'),
      onPressed: () {
        if (polylineAnnotation != null) {
          var lineString = polylineAnnotation!.geometry;
          var newlineString = LineString(
              coordinates: lineString.coordinates
                  .map((e) => Position(e.lng + 1.0, e.lat + 1.0))
                  .toList());
          polylineAnnotation?.geometry = newlineString;
          polylineAnnotationManager?.update(polylineAnnotation!);
        }
      },
    );
  }

  Widget _create() {
    return TextButton(
      child: Text('create a polyline annotation'),
      onPressed: () {
        createOneAnnotation();
      },
    );
  }

  void createOneAnnotation() {
    polylineAnnotationManager
        ?.create(PolylineAnnotationOptions(
            geometry: LineString(coordinates: [
              Position(
                1.0,
                2.0,
              ),
              Position(
                10.0,
                20.0,
              )
            ]),
            lineColor: Colors.red.value,
            lineWidth: 2))
        .then((value) => polylineAnnotation = value);
  }

  Widget _delete() {
    return TextButton(
      child: Text('delete a polyline annotation'),
      onPressed: () {
        if (polylineAnnotation != null) {
          polylineAnnotationManager?.delete(polylineAnnotation!);
        }
      },
    );
  }

  Widget _deleteMulti() {
    return TextButton(
        child: Text('delete 50 polyline annotations'),
        onPressed: () async {
          if (annotations.isNotEmpty) {
            final toDelete = annotations.take(50).toList();
            await polylineAnnotationManager?.deleteMulti(toDelete);
            annotations.removeRange(
                0, toDelete.length.clamp(0, annotations.length));
          }
        });
  }

  Widget _deleteAll() {
    return TextButton(
      child: Text('delete all polyline annotations'),
      onPressed: () {
        polylineAnnotationManager?.deleteAll();
        annotations.clear();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final MapWidget mapWidget =
        MapWidget(key: ValueKey("mapWidget"), onMapCreated: _onMapCreated);

    final List<Widget> listViewChildren = <Widget>[];

    listViewChildren.addAll(
      <Widget>[_create(), _update(), _delete(), _deleteMulti(), _deleteAll()],
    );

    final colmn = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Center(
          child: SizedBox(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 400,
              child: mapWidget),
        ),
        Expanded(
          child: ListView(
            children: listViewChildren,
          ),
        )
      ],
    );

    return Scaffold(
        floatingActionButton: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: <Widget>[
              FloatingActionButton(
                  child: Icon(Icons.swap_horiz),
                  heroTag: null,
                  onPressed: () {
                    mapboxMap?.style.setStyleURI(annotationStyles[
                        ++styleIndex % annotationStyles.length]);
                  }),
              SizedBox(height: 10),
              FloatingActionButton(
                  child: Icon(Icons.clear),
                  heroTag: null,
                  onPressed: () {
                    if (polylineAnnotationManager != null) {
                      mapboxMap?.annotations
                          .removeAnnotationManager(polylineAnnotationManager!);
                      polylineAnnotationManager = null;
                    }
                  }),
            ],
          ),
        ),
        body: colmn);
  }
}
